#! /bin/sh
#生成索引
java -jar {{ SUGGEST_INDEX_DEPLOY_PACKAGE_PATH }}/search-suggest {{ SUGGEST_INDEX_TASK_TYPE }} {{ SUGGEST_INDEX_TASK_SUBTYPE }} {{ SUGGEST_INDEX_DEPLOY_PACKAGE_PATH }}/data/index_input_data_book.dat {{ SUGGEST_INDEX_DEPLOY_PACKAGE_PATH }}/data/index {{ SUGGEST_INDEX_DEPLOY_PACKAGE_PATH }}/config/preprocessor/invalid.dat >> access.log;

#同一个日期的文件如果存在，就删除，保留最新的
backup={{ SUGGEST_INDEX_DEPLOY_PACKAGE_PATH }}/data/$(date +%Y%m%d)
if [ ! -d $backup ];then
echo ""
else
rm -rf $backup
fi

mkdir $backup
cp -a -R  {{ SUGGEST_INDEX_DEPLOY_PACKAGE_PATH }}/data/index/*  $backup;

#执行拷贝
     ansible {{ SUGGEST_INDEX_TASK_TRANSMIT_DEST_HOSTS }} -m synchronize -a 'src={{ SUGGEST_INDEX_DEPLOY_PACKAGE_PATH }}/data/index dest={{ SUGGEST_INDEX_TASK_TRANSMIT_DEST_PATH }} delete=yes'

#定期删除
oldDate=$(date -d "7 days ago" "+%Y%m%d")
cd /data/apps/SEARCH-SUGGEST-INDEX/data/
for i in $(ls -l | grep "[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]" | awk -F " " '{print $9}')
do
    if [[ "$i" < "$oldDate" ]] && [[ -d "$i" ]]
    then
      rm -rf "$i"
      echo "-----deleted------" $i 
    fi
done
